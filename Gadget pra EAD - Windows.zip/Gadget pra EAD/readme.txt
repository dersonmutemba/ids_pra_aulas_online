Este é um programa que automaticamente abre o ID e a lista de presenças

Os links estarão disponíveis por meio de um atalho no desktop

Requisitos:
    * Python3 instalado: pode instalar usando o seguinte link:
        https://www.python.org/downloads/
    * CMD Windows;
    * Capacidade de correr Bash Files

Enjoy e dê feedback.
https://github.com/dersonmutemba