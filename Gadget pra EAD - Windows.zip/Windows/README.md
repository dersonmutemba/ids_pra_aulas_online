# ids_pra_aulas_online
Este gadget foi criado para abrir IDs das aulas online do ISUTC, turma I23. Serve também para abrir listas de presença.

Os links estarão disponíveis por meio de um atalho no desktop

Requisitos:
    * Python3 instalado: pode instalar usando o seguinte link:
        https://www.python.org/downloads/
    * CMD Windows;
    * Capacidade de correr Bash Files

Enjoy e dê feedback.
https://github.com/dersonmutemba
