Este é um programa que automaticamente abre o ID e a lista de presenças

Os links estarão disponíveis por meio de um atalho no desktop
Corra o python file. Depois disso mude as permissoes dos atalhos no desktop e ja esta :)

Requisitos:
    * Python3 instalado: pode instalar usando o seguinte link:
        https://www.python.org/downloads/
    * Capacidade mudar um shell script pra executavel

Enjoy e dê feedback.
https://github.com/dersonmutemba
